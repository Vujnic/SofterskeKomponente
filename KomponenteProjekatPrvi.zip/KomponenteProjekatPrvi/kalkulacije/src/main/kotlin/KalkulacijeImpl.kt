package kalkulacije


interface KalkulacijeImpl {


    fun izracunajProsecneOcene(data: Map<String, List<String>>): Map<String, List<String>> {
        val result = data.toMutableMap()
        val proseci = data["matematika"]?.indices?.map { index ->
            val matematika = data["matematika"]?.get(index)?.toDoubleOrNull() ?: 0.0
            val informatika = data["informatika"]?.get(index)?.toDoubleOrNull() ?: 0.0
            val fizika = data["fizika"]?.get(index)?.toDoubleOrNull() ?: 0.0
            val istorija = data["istorija"]?.get(index)?.toDoubleOrNull() ?: 0.0
            val geografija = data["geografija"]?.get(index)?.toDoubleOrNull() ?: 0.0
            (matematika + informatika + fizika + istorija + geografija) / 5
        }?.map { it.toString() } ?: listOf()

        result["prosek"] = proseci
        return result
    }

    private fun sum(){

    }

    private fun count(){

    }
}