import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import spec.ReportInterface
import java.io.InputStreamReader
import java.sql.DriverManager
import java.sql.SQLException
import java.util.*

data class Schedule(
    val ime : String,
    val prezime : String,
    val matematika : Int,
    val informatika : Int,
    val fizika : Int,
    val istorija : Int,
    val geografija : Int
)

fun prepareData(jsonData: InputStreamReader): Map<String, List<String>> {
    val gson = Gson()
    val scheduleType = object : TypeToken<List<Schedule>>() {}.type
    val schedules: List<Schedule> = gson.fromJson(jsonData, scheduleType)

    // Convert the list into a Map<String, List<String>> where key is column name and value is a list of corresponding column data
    val reportData: Map<String, List<String>> = mapOf(
        "ime" to schedules.map { it.ime },
        "prezime" to schedules.map { it.prezime},
        "matematika" to schedules.map { it.matematika.toString() },
        "informatika" to schedules.map { it.informatika.toString() },
        "fizika" to schedules.map { it.fizika.toString() },
        "istorija" to schedules.map { it.istorija.toString() },
        "geografija" to schedules.map { it.geografija.toString() }
    )

    return reportData
}

fun main() {
    /*
    val properties = Properties().apply {
        put("user", "root")
        put("password", "MornarPopaj")
    }

    try {
        DriverManager.getConnection("jdbc:mysql://localhost:3306/ucenici", properties)
    } catch (e: SQLException) {
        throw RuntimeException("Error connecting to the database", e)
    }
    */
    /*
    val properties = Properties()
    properties["user"] = "root"
    properties["password"] = ""
    try {
       val connection = DriverManager.getConnection("jdbc:mysql://localhost:3315//ucenici", properties)
    } catch (e: SQLException) {
        throw RuntimeException(e)
    }*/

    val serviceLoader = ServiceLoader.load(ReportInterface::class.java)

    val exporterServices = mutableMapOf<String, ReportInterface> ()

    serviceLoader.forEach{
            service ->
        exporterServices[service.implName] = service
    }

    println(exporterServices.keys)

    val inputStream = object {}.javaClass.getResourceAsStream("/data2.json")
    val reader = InputStreamReader(inputStream)
    val data = prepareData(reader)
    reader.close()

    println(data)

    println("Izaberite zeljeni format")
    println("Moguci formati:\n" +
            "1. CSV\n" +
            "2. txt\n" +
            "3. PDF\n" +
            "4. Eksel")
    val formattxt = readln()
    val st:String
    val tekst:String
    println("Da li zelite i srednju ocenu djaka?(1 je da, 0 je ne)")
    val flag = readln().toInt()
    if(formattxt.toInt() == 1){
        tekst = "izlaz9.csv"
        st = "CSV"
        val format = exporterServices[st]
        format?.generateReport(data, tekst,  true, null, null, flag)
    } else if(formattxt.toInt() == 2){
        tekst = "izlaz9.txt"
        st = "TXT"
        val format = exporterServices[st]
        println("Ako ne zelite naslov ostavite prazno, a ako zelite unesite zeljeni")
        val naslov = readln()
        println("Ako ne zelite rezime ostavite prazno, a ako zelite unesite zeljeni")
        val rezime = readln()
        format?.generateReport(data, tekst,  true, naslov, rezime, flag)
    } else if(formattxt.toInt() == 3){
        tekst = "izlaz9.pdf"
        st = "PDF"
        val format = exporterServices[st]
        println("Ako ne zelite naslov ostavite prazno, a ako zelite unesite zeljeni")
        val naslov = readln()
        println("Ako ne zelite rezime ostavite prazno, a ako zelite unesite zeljeni")
        val rezime = readln()
        format?.generateReport(data, tekst,  true, naslov, rezime, flag)
    } else {
        tekst = "izlaz9.xlsx"
        st = "XLS"
        val format = exporterServices[st]
        format?.generateReport(data, tekst,  true, null, null, flag)
    }



}